//Skelton:
  //=.s
  //#include "data.regmap_bus.c"					//202306 perform good in KT5.15.76
  #include "data.regmap_bus_sv510complex1.c"		//202306 for newer KT version than KT5.15.76
  //[#include "data.regmap_bus_sv510complex2.c"]	//202306 for newest KT version than KT5.15.76 or later
  //=.e
