#ifndef	DM9051_SKBPROT_H_
#define	DM9051_SKBPROT_H_

 /* Such as extention for something. */
 
 #define	DM9051_SKB_PROTECT	//'wb'

#endif //DM9051_SKBPROT_H_
