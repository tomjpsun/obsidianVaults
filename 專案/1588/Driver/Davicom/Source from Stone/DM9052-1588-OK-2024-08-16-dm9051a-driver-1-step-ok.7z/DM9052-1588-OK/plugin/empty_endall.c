/*
 * Data structure definition
 */
#ifndef	DM9051_DESC_H_

 /*#define	DM9051_DESC_H_ */
 /* Empty while DESC-usage as disable. Also 
  * Keep 'DM9051_DESC_H_' undefine. */

#endif //DM9051_DESC_H_

#ifndef	CACHE_SKB_H_

 /*#define	CACHE_SKB_H_ */
 /* Empty while SKB-usage as disable. Also 
  * Keep 'CACHE_SKB_H_' undefine. */

#endif //CACHE_SKB_H_

#ifndef	DM9051_COVER_DTS_H_

 /* #define	DM9051_COVER_DTS_H_ */
 /* Empty while DTS-usage as disable. Also 
  * Keep 'DM9051_COVER_DTS_H_' undefine. */

#endif //DM9051_COVER_DTS_H_

#ifndef	DM9051_SKBPROT_H_

 /* #define	DM9051_SKBPROT_H_ */
 /* Empty while nothing. */

#endif //DM9051_SKBPROT_H_
