#if CODE_SPIREGISTER_NDTS_SRC_CODE
 //#include "dm9051_plugin_internal_dts_v0.0.3.c"	//(Joseph CHANG)
#endif //CODE_SPIREGISTER_NDTS_SRC_CODE
 //
 //(1) internal dts mode (fixed coding)
 //(1-1) option 1-1 (check to 'kernel_config_conf.h')
 //#define _DM_CONF_MAX_SPEED_HZ 31200000
 //#define _DM_CONF_INTERRUPT_IRQ	26
 //#define _DRV_SPI_BUS_NUMBER   0
 //#define _DRV_SPI_CHIP_SELECT  1
