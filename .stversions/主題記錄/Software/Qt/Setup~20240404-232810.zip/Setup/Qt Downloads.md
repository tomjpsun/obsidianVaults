Qt 5.12.12 Offline Installers
https://www.qt.io/offline-installers
有下載一份放在 Team-player NAS **/public/develop/Qt Installer**

Qt 6.x for Open Source Development  
[Download the Qt Online Installer](https://www.qt.io/download-open-source) 頁面中間有 Download 按鈕，可以前往
[Download Qt for open source use](https://www.qt.io/download-qt-installer-oss?hsCtaTracking=99d9dd4f-5681-48d2-b096-470725510d34%7C074ddad0-fdef-4e53-8aa8-5e8a876d6ab4) 下載



